<head>
	<title>Login</title>
	<link rel="stylesheet" href="login.css">
</head>
	<div class="header">
		<h1><img src="peacheur.png" width="500"></h1>
	</div>

	<div class="menu">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li>Product</li>
			<li>Search</li>
			<li>Information</li>
			<li><a href="#contact">Contact</a></li>
			<li><a href="login.php">Login</a></li>
			<li><a href="signup.php">Sign Up</a></li>
		</ul>
	</div>
<form class="box" action="index.php" method="post">
	<h1>Login</h1>
	<input type="text" name="" placeholder="Username">
	<input type="password" name="" placeholder="password">
	<input type="submit" name="" value="login">
</form>


	