<!DOCTYPE html>
<html>
<head>
	<title>Peacheur</title>
	<link rel="stylesheet" href="index.css">
</head>
<body>
	<div class="header">
		<h1><img src="peacheur.png" width="500"></h1>
	</div>

	<div class="menu">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li>Product</li>
			<li>Search</li>
			<li>Information</li>
			<li><a href="#contact">Contact</a></li>
			<li><a href="login.php">Login</li>
			<li><a href="signup.php">Sign Up</li>
		</ul>

	</div>
	<div class="content">
			<div class="product">
				<a href="lighstick.php">
				<img src="lighstick.png" alt="">
				</a>
			</div>

			<div class="product">
				<a href="painting.php">
				<img src="painting.png" alt="">
				</a>
			</div>

	</div>
	<p id="contact" style="font-weight: bold;">Follow Me!<h1></h1><a href="http://www.instagram.com/raninovializa">
	<img src="instagram.png" width="40"></a>
	<a href="http://www.twitter.com/novializarani">
	<img src="twitter.png" width="50"></a>
	</p>
</body>
</html>